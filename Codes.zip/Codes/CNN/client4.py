import flwr as fl
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, Input
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from PIL import Image
import json
import os

def load_images(path, label):
    images = []
    labels = []
    for img_name in os.listdir(path):
        if not img_name.lower().endswith(('.png', '.jpg', '.jpeg')):
            continue
        img_path = os.path.join(path, img_name)
        with Image.open(img_path) as img:
            img = img.convert('RGB').resize((100, 100))
            images.append(np.array(img) / 255.0)
            labels.append(label)
    return np.array(images), np.array(labels)

class CovidClient(fl.client.NumPyClient):
    def __init__(self, model, x_train, y_train, x_test, y_test):
        self.model = model
        self.x_train = x_train
        self.y_train = y_train
        self.x_test = x_test
        self.y_test = y_test

    def get_parameters(self, **kwargs):
        return self.model.get_weights()

    def set_parameters(self, parameters, **kwargs):
        self.model.set_weights(parameters)

    def fit(self, parameters, config):
        ep=0
        self.set_parameters(parameters)
        self.model.fit(self.x_train, self.y_train, epochs=10, batch_size=10, verbose=2)
        loss, accuracy = self.model.evaluate(self.x_test, self.y_test, verbose=0)
        predictions = self.model.predict(self.x_test)
        pred_labels = np.argmax(predictions, axis=1)
        cr = classification_report(self.y_test, pred_labels, output_dict=True)
        cm = confusion_matrix(self.y_test, pred_labels)

        metrics = {
            "loss": loss,
            "accuracy": accuracy,
            "precision": cr['weighted avg']['precision'],
            "recall": cr['weighted avg']['recall'],
            "f1-score": cr['weighted avg']['f1-score'],
            "confusion_matrix": json.dumps(cm.tolist()) 
        }
        print(f"Epoch {ep+1} : metrics are : {metrics}")
        ep+=1
        return self.model.get_weights(), len(self.x_train), metrics

    def evaluate(self, parameters, config, **kwargs):
        self.set_parameters(parameters)
        loss, accuracy = self.model.evaluate(self.x_test, self.y_test, verbose=0)
        return loss, len(self.x_test), {"accuracy": accuracy}

def main():
    covid_path = r"D:\Capstone\Dataset2_zip\Dataset2\client_4\covid"
    normal_path = r"D:\Capstone\Dataset2_zip\Dataset2\client_4\normal"
    x_covid, y_covid = load_images(covid_path, 1)
    x_normal, y_normal = load_images(normal_path, 0)
    x = np.concatenate((x_covid, x_normal), axis=0)
    y = np.concatenate((y_covid, y_normal), axis=0)
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

    lr = 0.001

    # Define the optimizer with the specified learning rate
    opt = tf.keras.optimizers.Adam(learning_rate=lr)
    
    model = models.Sequential([
        Input(shape=(100, 100, 3)),
        layers.Conv2D(32, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.Flatten(),
        layers.Dense(64, activation='relu'),
        layers.Dense(2, activation='softmax')
    ])
    model.compile(optimizer=opt, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    
    fl.client.start_client(server_address="localhost:8080", client=CovidClient(model, x_train, y_train, x_test, y_test).to_client())

if __name__ == "__main__":
    main()

