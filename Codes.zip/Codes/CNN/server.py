import flwr as fl
from flwr.server.strategy import FedAvg

class CustomStrategy(FedAvg):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.round = 0

    def aggregate_fit(self, rnd, results, failures):
        weights, aggregate_metrics = super().aggregate_fit(rnd, results, failures)

        print(f"Round {rnd} metrics aggregated from all clients:")
        for idx, (client_proxy, fit_res) in enumerate(results):
            print(f"Client {idx} precision: {fit_res.metrics['precision']}")
            print(f"Client {idx} recall: {fit_res.metrics['recall']}")
            print(f"Client {idx} f1-score: {fit_res.metrics['f1-score']}")
            print(f"Client {idx} confusion_matrix: {fit_res.metrics['confusion_matrix']}")

            # Print individual metrics:
            print(f"Client {idx} loss: {fit_res.metrics['loss']}")
            print(f"Client {idx} accuracy: {fit_res.metrics['accuracy']}")
            # ... Access and print other metrics similarly

        # Example: Calculate average accuracy across clients
        total_accuracy = sum(fit_res.metrics['accuracy'] for _, fit_res in results)
        average_accuracy = total_accuracy / len(results)
        print(f"Round {rnd} average accuracy: {average_accuracy}")

        self.round += 1
        return weights, aggregate_metrics


    def on_aggregation_end(self, rnd, results, failures):
        if rnd == self.num_rounds - 1:  
            print("Final round metrics aggregated from all clients:")
            for idx, (client_proxy, fit_res) in enumerate(results):
                print(f"Client {idx} final metrics: {fit_res[2]}") 

if __name__ == "__main__":
    # Define strategy with a minimum of 5 required clients
    strategy = CustomStrategy(min_available_clients=5)

    # Start Flower server with the defined strategy and configuration
    fl.server.start_server(
        server_address="localhost:8080",
        config=fl.server.ServerConfig(num_rounds=2),
        strategy=strategy
    )
