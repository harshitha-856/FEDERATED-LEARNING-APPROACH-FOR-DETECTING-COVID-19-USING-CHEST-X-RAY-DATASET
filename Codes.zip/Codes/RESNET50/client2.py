import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import numpy as np
from keras.preprocessing import image
from keras.utils import to_categorical
from keras.applications import ResNet50
from keras.models import Model
from keras.layers import Flatten, Dense
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
import flwr as fl
import json

# Function to load images and labels from a directory
def load_data(directory):
    images = []
    labels = []
    for label in os.listdir(directory):
        label_dir = os.path.join(directory, label)
        for image_file in os.listdir(label_dir):
            img_path = os.path.join(label_dir, image_file)
            img = image.load_img(img_path, target_size=(224, 224))  # ResNet50 input size
            img_array = image.img_to_array(img)
            images.append(img_array)
            labels.append(label)
    return np.array(images), np.array(labels)

# Load images and labels from the provided dataset
train_data_directory = r"D:\Capstone\Dataset2_zip\Dataset2\client_2"
train_images, train_labels = load_data(train_data_directory)

# Split the dataset into training and testing sets
train_images, test_images, train_labels, test_labels = train_test_split(train_images, train_labels, test_size=0.2, random_state=42)

# Perform one-hot encoding on the labels for training and testing data
label_mapping = {'covid': 0, 'normal': 1}  # Map label strings to integers
train_labels = np.array([label_mapping[label] for label in train_labels])
test_labels = np.array([label_mapping[label] for label in test_labels])
train_labels = to_categorical(train_labels, num_classes=2)
test_labels = to_categorical(test_labels, num_classes=2)

# Load pre-trained ResNet50 model
resnet_model = ResNet50(weights='imagenet', include_top=False, input_shape=(224, 224, 3))

# Freeze pre-trained layers
for layer in resnet_model.layers:
    layer.trainable = False

# Add custom classification layers on top of ResNet50
x = Flatten()(resnet_model.output)
x = Dense(128, activation='relu')(x)
predictions = Dense(2, activation='softmax')(x)

# Create a new model combining ResNet50 and custom layers
model = Model(inputs=resnet_model.input, outputs=predictions)

# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Use Flower to create a NumPyClient
class CovidXRayClient(fl.client.NumPyClient):
    def get_parameters(self, **kwargs):
        return model.get_weights()

    def fit(self, parameters, config):
        model.set_weights(parameters)
        history = model.fit(train_images, train_labels, epochs=1, batch_size=32)
        self.model.fit(self.x_train, self.y_train, epochs=1, batch_size=10, verbose=2)
        loss, accuracy = self.model.evaluate(self.x_test, self.y_test, verbose=0)
        predictions = self.model.predict(self.x_test)
        pred_labels = np.argmax(predictions, axis=1)
        cr = classification_report(self.y_test, pred_labels, output_dict=True)
        cm = confusion_matrix(self.y_test, pred_labels)

        metrics = {
            "loss": loss,
            "accuracy": accuracy,
            "precision": cr['weighted avg']['precision'],
            "recall": cr['weighted avg']['recall'],
            "f1-score": cr['weighted avg']['f1-score'],
            "confusion_matrix": json.dumps(cm.tolist()) 
        }
        return self.model.get_weights(), len(self.x_train), metrics

    def evaluate(self, parameters, config):
        model.set_weights(parameters)
        loss, accuracy = model.evaluate(test_images, test_labels)
        # Return the accuracy of the local model after evaluation
        return loss, len(test_images), {"accuracy": accuracy}

# Start Flower client
fl.client.start_numpy_client(server_address="localhost:8080", client=CovidXRayClient())
