import flwr as fl
from flwr.server.strategy import FedAvg

class CustomStrategy(FedAvg):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.round = 0  # Initialize round number to track rounds

    def aggregate_fit(self, rnd, results, failures):
        # Perform the usual aggregation
        weights, metrics = super().aggregate_fit(rnd, results, failures)
        # Print the round number
        print(f"Round {self.round} completed")
        self.round += 1  # Increment the round count after completion
        return weights, metrics

if __name__ == "__main__":
    # Define strategy with a minimum of 5 required clients
    strategy = CustomStrategy(min_available_clients=3)
    
    # Start Flower server with the defined strategy and configuration
    fl.server.start_server(
        server_address="localhost:8080",
        config=fl.server.ServerConfig(num_rounds=5),
        strategy=strategy
    )
