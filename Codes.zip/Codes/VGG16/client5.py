import flwr as fl
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import VGG16
from tensorflow.keras import layers, models, Input
from sklearn.model_selection import train_test_split
from PIL import Image
import os

def load_images(path, label):
    images = []
    labels = []
    for img_name in os.listdir(path):
        if not img_name.lower().endswith(('.png', '.jpg', '.jpeg')):
            continue
        img_path = os.path.join(path, img_name)
        with Image.open(img_path) as img:
            img = img.convert('RGB').resize((100, 100))
            images.append(np.array(img) / 255.0)
            labels.append(label)
    return np.array(images), np.array(labels)

def create_vgg16_model(input_shape):
    base_model = VGG16(weights='imagenet', include_top=False, input_tensor=Input(shape=input_shape))
    base_model.trainable = False  # Freeze layers
    flatten = layers.Flatten()(base_model.output)
    dense1 = layers.Dense(256, activation='relu')(flatten)
    output = layers.Dense(2, activation='softmax')(dense1)
    model = models.Model(inputs=base_model.input, outputs=output)
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

class CovidClient(fl.client.NumPyClient):
    def __init__(self, model, x_train, y_train, x_test, y_test):
        self.model = model
        self.x_train = x_train
        self.y_train = y_train
        self.x_test = x_test
        self.y_test = y_test

    def get_parameters(self, config=None):
        return self.model.get_weights()

    def set_parameters(self, parameters):
        self.model.set_weights(parameters)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        self.model.fit(self.x_train, self.y_train, epochs=1, batch_size=10, verbose=2)
        return self.model.get_weights(), len(self.x_train), {}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        loss, accuracy = self.model.evaluate(self.x_test, self.y_test, verbose=0)
        return loss, len(self.x_test), {"accuracy": accuracy}

def main():
    covid_path = r"D:\Capstone\Dataset2_zip\Dataset2\client_5\covid"
    normal_path = r"D:\Capstone\Dataset2_zip\Dataset2\client_5\normal"
    x_covid, y_covid = load_images(covid_path, 1)
    x_normal, y_normal = load_images(normal_path, 0)

    x = np.concatenate((x_covid, x_normal), axis=0)
    y = np.concatenate((y_covid, y_normal), axis=0)
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

    model = create_vgg16_model((100, 100, 3))
    fl.client.start_client(server_address="localhost:8080", client=CovidClient(model, x_train, y_train, x_test, y_test).to_client())

if __name__ == "__main__":
    main()
